DROP TABLE `prefix_talk_bell`
