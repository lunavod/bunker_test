LiveStreet (v.1.x)
Plugin Talk Bell (v.0.3)
Copyright В© 2011 Bishovec Nikolay

Plugin Page: http://netlanc.net
CMS Page http://livestreetcms.com
Contact e-mail: netlanc@yandex.ru

ОПИСАНИЕ
Плагин выводит уведомления о новых сообщениях в личку, без перезагрузки страницы, при этом сопровождая уведомления звуковым сообщением.

ЛИЦЕНЗИЯ
Плагин распространяется  по лицензии Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0) (http://creativecommons.org/licenses/by-sa/3.0/deed.ru)
Обязательным условием использования плагина является наличие активной ссылки на сайт указаный разработчиком,
которая уже прописана в плагине. Отключить ссылку можно за донейт от 5уе.

УСТАНОВКА:
1. Скопировать плагин в каталог /plugins/
2. Через панель управления плагинами (/admin/plugins/) запустить его активацию.
3. Выполнить настройки плагина в файле /plugins/talkbell/config/config.php
4. Радоваться ;)


ОБНОВЛЕНИЯ
v0.3
- адаптирован к версии LS1x, совместим с шаблоами: synio, developer, new, social, banana, lightblue

ВАШЕ УЧАСТИЕ

Если Вы хотите поддержать написание бесплатных плагинов и можете помочь материально:

http://livestreet.ru/profile/netlanc/
http://netlanc.net/

СПОНСОРЫ
Спонсор v0.3 - http://catalognica.ru