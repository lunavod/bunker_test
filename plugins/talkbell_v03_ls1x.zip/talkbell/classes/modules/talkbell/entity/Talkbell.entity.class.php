<?php

class PluginTalkbell_ModuleTalkbell_EntityTalkbell extends Entity{

}

?>
